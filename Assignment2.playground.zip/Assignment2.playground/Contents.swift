//Name - Thet Hlaing Phyo
//Exercise 15
let player = (8, "Igor Larionov")

//Exercise 16
let number = player.0
let name = player.1

//Exercise 17
let value: Int? = nil
let otherValue: Int? = 6
//Yes it is possible to have constant type have optional

//Exercise 18
let value1: Int? = 17
let banana: Int = value1!
//! have to added to force unwrapped.

//Exercise 19
let value2: Int? = nil
let banana1: Int = value2 ?? 0
//It will have error because nil cannot be force unwrapped we have to use nil coalising operator to have default value.

//Exercise 20
//We can use nil coalising operator to have default value is a better way to assign value to banana constant

//Exercise 21
var first = 10
var second = 20
if first == second {
    print(3 * (first+second))
}
else {
    print(first+second)
}

//Exercise 22
var arr = [3, 1, 2, 3, 4, 4]
if (arr[0] == 5 || arr[arr.count - 1] == 5)
{
    print("5 is in first or last place.")
}
else
{
    print("5 is not in first or last place.")
}

//Exercise 23
var newArr = Array(arr.reversed())
print(newArr)

//Exercise 24
var array = [1,2,3]
let f = array[0]
var arrayCopy = array
for i in 0..<arrayCopy.count - 1 {
    arrayCopy[i] = arrayCopy[i+1]
}
arrayCopy[array.count-1] = f
print(arrayCopy)

//Exercise 25
var test1 = [0, 1, 2, 3]
var sum : Int = 0
for i in 0...test1.count-1
{
    sum += test1[i]
}
print(sum)

//Exercise 26
var n : Int = 3
if n > 51
{
    print(2 * abs(n - 51))
}
else
{
    print(abs(n - 51))
}

//Exercise 27
var fir : Int = 2
var sec : Int = 18
if(fir == 20 || sec == 20 || (fir + sec) == 20)
{
    print("True")
}
else
{
    print("False")
}

//Exercise 28
var tes0 : Int = -2
var tes1 : Int = -4
if(tes0 < 0 && tes1 < 0)
{
    print("True")
}
else if ((tes0 < 0 && tes1 > 0) || (tes0 > 0 && tes1 < 0))
{
    print("True")
}
else
{
    print("False")
}

//Exercise 29
var num0 = 34
var num1 = 9
if((num0 >= 10 && num0 <= 30) || (num1 >= 10 && num1 <= 30)) {
    print("True")
}
else {
    print("False")
}

//Exercise 30
var str = "Apple"
str.removeFirst()
var i = str.index(str.startIndex, offsetBy: 0)
str.insert("a", at: i)
str.removeLast()
var j = str.index(str.startIndex, offsetBy: str.count)
str.insert("E", at: j)
print(str)
