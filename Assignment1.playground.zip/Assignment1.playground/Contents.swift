//Exercise 1
var temperature: Float = 64.5
temperature = 75.4

//Exercise 2
let secondsInHour: Int = 3600
//secondsInHour = 2400
//It doesn't work because it is a constant variable so we cannot reassign another value

//Exercise 3
var num: Int
var num1 = 2

//Exercise 4
let numOfWheel: Int
numOfWheel = 4
//This work because we haven't assign a value to constant variable, once it assigned, it cannot be reassign

//Exercise 5
let π: Double

//Exercise 6
var 👍 = "Thump Up"

//Exercise 7
var temp = 10
print(temp)

//Exercise 8
//maximum number that can be stored in Int16 is 32767
print(Int16.max)
//32767 is the maximum number of Int16
let pi = 3 + 0.141592654
//pi type is double because we are adding integer and double values after adding two values, and assign it to pi then, pi became double type.

//Exercise 9
//let myNumber: UInt = -17
//it overflows for unsigned type because unsigned can never be negative.

//Exercise 10
//let bigNumber: Int16 = 32767 + 1
//it overflows because Int16 max number is 32767 so 1 more is overflow.

//Exercise 11
//It doesn't work because we are assigning double values to integer so if we don't want to change the type, then we have to integer type casting to double value.
let pi1 = 3.141592654
let approximatePi: Int = Int(pi1)

//Exercise 12
//Single Line comment
/*
 multiline
 comment
 */

//Exercise 13
/*
 Outside Nested Comment
 /*
  Inside Nested Comment
  */
 */

//Exercise 14
print("Hi My name is Thet.\nI am learning IOS Programming.")

