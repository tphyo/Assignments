//Name - Thet Hlaing Phyo
//Assignment 3 - Swift Basics 3
//Exercise 1
func add(n1: Int, n2: Int) -> Int
{
    return n1 + n2
}
print(add(n1: 1, n2: 2))

//Exercise 2
//We cannot add different data type, so we have to cast them to make them into same type.
let n1: Int = 1
let n2: Float = 2.0
let n3: Double = 3.34

var result = Double(n1) + Double(n2) + n3
print(result)

//Exercise 3
/*
 init() is initializer in swift. It is used to initialize stored properties.
 */

//Exercise 4
/*
 In Swift, a protocol is a blueprint of methods or properties that can be used by classes.
 */
protocol Blueprint {
    //blueprint of properties
    var name: String { get }
    
    //blueprint of method
    func display()
}

//protocol must be conformed by classes with actual implementation in it
class Employee: Blueprint {
    //actual implementation of properties
    var name = "Gary"
    
    //actual implementation of method
    func display()
    {
        print("Good Evening")
    }
}

var employee = Employee()
employee.display()

//Exercise 5
/*
 Double Question Mark Operator is nil coalescing operator. It is used to check whether the variable is nil, then it will use the default value set by nil coalescing operator.
 */

//Exercise 6
/*
 Guard statement allow you to write error handling without if case. guard (condition) else {...} then if the condition is false, then it will print the else case. if the condition is true, then it will execute the code after the guard statement.
 */

//Exercise 7
/*
 Three primary collection type in swift are array, sets and dictionaries.
 */

//Exercise 8
/*
 Struct are value type and classes are reference type. If we create multiple object with struct, and we change one property, then other object won't change because it is value type. For class, if we create multiple object, and we change one of the property of an object, then other object get change as well. Another difference is struct doesn't allow inheritance but class have inheritance.
 */

//Differences of classes and struct
struct Rectangle {
    var length = 0
    //var width = 0
}

var temp = Rectangle()
var temp1 = temp
temp1.length = 11 //unique object don't get change if other object change
print(temp.length)

class NewRectangle {
    var length = 0
    //var width = 0
}

var temp0 = NewRectangle()
var temp2 = temp0
temp0.length = 11 //reference object get change when one object property is changed
print(temp2.length)

//Exercise 9
//Optional chaining is a process for calling properties and methods on an optional that might currently be nil.
class Person {
    var residence: Residence?
}

class Residence {
    var numberOfRooms = 10
}

var john = Person()
//john.residence? is optional chaining.
let roomCount = john.residence?.numberOfRooms
print(roomCount)

//Exercise 10
//Optional binding is a mechanism to safely unwrapped optional.
john.residence = Residence()
//Optional Binding
if let roomCount = john.residence?.numberOfRooms {
    print("John's residence has \(roomCount) room(s).")
} else {
    print("Unable to retrieve the number of rooms.")
}

//Exercise 11
/*
 In-Out parameter is used to put value back in the argument that is passed with & in arguments.
 */
func swapTwoInts(_ a: inout Int, _ b: inout Int)
{
    let temp = a
    a = b
    b = temp
}

var first0 = 3
var second0 = 10
swapTwoInts(&first0, &second0)
print(first0)
print(second0)

//Exercise 12
/*
 Yes, it is possible to give default value to function parameter.
 */

func addition(n1: Int = 3, n2: Int = 3)
{
    print(n1 + n2)
}
addition(n1: 5, n2: 5)
addition()

//Exercise 13
/*
 Force Unwrapping is used to unwrap the optional value to get the value inside. ! is used to unwrap the optional value just like below solution.
 */

var test : Int? = 3
print(test!)

//Exercise 14
/*
 Mutating keyword is used to modify struct properties by function.
 */

struct Human {
    var age = 0
    mutating func increase() {
        age = age + 1
        print(age)
    }
}

var h1 = Human()
h1.increase()

//Exercise 15
/*
 Deinitializer is used to deinitialize the object from memory.
 */

class Garage {
    
    var numberOfVehicles : Int
    
    init(){
        numberOfVehicles = 0
    }
    //deinitializer - ARC : Automatic Reference Counting
    deinit {
        print("Object is deallocated from Memory")
    }
}

var result1: Garage? = Garage()
print(result1!.numberOfVehicles)
result1 = nil //to deinitalize the object
print(result1?.numberOfVehicles)

//Exercise 16
/*
In Swift, a protocol is a blueprint of methods or properties that can be used by classes.
*/

//Exercise 17
/*
 Difference between protocol and class are protocol has properties and method header where class has properties initalization and method actual implementation. Protocol is blueprint so blueprint only have the structure and not the actual implementation like class is.
 */

//Exercise 18
struct Apple {

}

func pick(apple: Apple?) {
  guard let apple = apple else {
    print("No apple found!")
      return
  }
  print(apple)
}

//Exercise 19
protocol A {
    func a()
}

protocol B {
    func b()
}

class AB : A , B {
    func a() {
        print("A")
    }
    
    func b() {
        print("B")
    }
}

//Exercise 20
var first = ["John", "Paul"]
let second = ["George", "Ringo"]
first.append(contentsOf: second)
print(first)
